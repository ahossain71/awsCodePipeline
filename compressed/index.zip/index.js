/// Define libraries to connect easly to EC2 instance.
var SSH = require('simple-ssh');
var fs  = require('fs');
var wget = require('wget');
// This is the full S3 URL object that you need to download the file.
//var Ec2_key_url= 'https://s3.amazonaws.com/codepipeline-us-east-1-315212479732/CodeDeployBuildServer.pem';
var dplmnt_pkg_url= 'https://s3.amazonaws.com/codepipeline-us-east-1-315212479732/index.zip';
var Ec2_key_url= 'CodeDeployBuildServer.pem';
//var dplmnt_pkg_url= 'index.html';

/**************************************************/
/*                      SSH                       */
/**************************************************/
exports.handler = (event, context, callback) => {
var ssh = new SSH({
    host: 'ec2-34-204-92-58.compute-1.amazonaws.com',
    user: 'admin',
    passphrase: 'adminadmin', // If you have one
    key : fs.readFileSync(Ec2_key_url), // The credential that you need to connect to your EC2 instance through SSH
});

// wget will download the file from the URL we passed
ssh.exec('cd /usr/share/tomcat7/webapps/unzipped').exec('sudo wget --no-check-certificate --no-proxy ' + dplmnt_pkg_url).start();
};


